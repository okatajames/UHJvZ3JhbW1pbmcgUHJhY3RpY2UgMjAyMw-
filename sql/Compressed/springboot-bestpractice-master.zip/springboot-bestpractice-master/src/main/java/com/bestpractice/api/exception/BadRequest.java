package com.bestpractice.api.exception;

public class BadRequest extends RuntimeException {
}
