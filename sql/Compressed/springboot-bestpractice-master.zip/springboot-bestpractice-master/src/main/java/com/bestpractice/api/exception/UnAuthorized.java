package com.bestpractice.api.exception;

public class UnAuthorized extends RuntimeException {
}
