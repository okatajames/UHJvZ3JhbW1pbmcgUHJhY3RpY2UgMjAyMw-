package com.bestpractice.api.exception;

public class Forbidden extends RuntimeException {
}
