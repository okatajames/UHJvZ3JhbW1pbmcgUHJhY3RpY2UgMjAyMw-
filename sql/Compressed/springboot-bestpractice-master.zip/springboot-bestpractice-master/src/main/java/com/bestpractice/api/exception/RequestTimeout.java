package com.bestpractice.api.exception;

public class RequestTimeout extends RuntimeException {
}
