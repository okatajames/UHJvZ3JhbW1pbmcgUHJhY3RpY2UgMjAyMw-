package com.bestpractice.api.exception;

public class NotFound extends RuntimeException {
}
