package com.bestpractice.api.exception;

public class ServiceUnavailable extends RuntimeException {
}
