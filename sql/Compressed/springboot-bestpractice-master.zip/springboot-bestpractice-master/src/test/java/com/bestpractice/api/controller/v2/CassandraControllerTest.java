package com.bestpractice.api.controller.v2;

import static org.junit.Assert.*;

public class CassandraControllerTest {

}