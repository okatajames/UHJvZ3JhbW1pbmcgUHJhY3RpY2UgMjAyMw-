package com.bestpractice.api.controller.v1;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest
public class RdbmsControllerTest {

    @Test
    public void getInfos() {
    }

    @Test
    public void getInfo() {
    }

    @Test
    public void postInfo() {
    }

    @Test
    public void putInfo() {
    }

    @Test
    public void deleteInfo() {
    }
}