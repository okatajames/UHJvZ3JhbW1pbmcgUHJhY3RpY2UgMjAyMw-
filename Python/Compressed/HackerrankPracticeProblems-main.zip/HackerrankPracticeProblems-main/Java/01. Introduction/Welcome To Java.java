// Problem - https://www.hackerrank.com/challenges/welcome-to-java/problem?isFullScreen=true
// Score - 3
// Difficulty - Easy


public class WelcomeToJava {
    public static void main(String[] args)
    {
        System.out.println("Hello, World.");
        System.out.println("Hello, Java.");
    }
}