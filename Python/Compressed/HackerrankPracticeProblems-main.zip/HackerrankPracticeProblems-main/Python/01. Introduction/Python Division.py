# Problem: https://www.hackerrank.com/challenges/python-division/problem?isFullScreen=true
# Score: 10
# dificulty: Easy

if __name__ == '__main__':
    a = int(input())
    b = int(input())
    
    print(a//b) # integer division
    print(a/b) # float division
    