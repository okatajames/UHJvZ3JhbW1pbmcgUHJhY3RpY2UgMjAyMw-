// Problem Link :https://www.hackerrank.com/challenges/rectangle-area/problem
//Difficulty : Easy
//Max Score:25


#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    int h,w;
    //taking input 
    cin>>h>>w;
    //print height and width
    cout<<h<<" "<<w<<endl;
    // print the calculated area 
    cout<<h*w ;
    return 0;
}
