// Problem : https://www.hackerrank.com/challenges/cpp-hello-world/problem
// Score: 5.0
// Difficulty : Easy

#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    cout << "Hello, World!";
    return 0;
}