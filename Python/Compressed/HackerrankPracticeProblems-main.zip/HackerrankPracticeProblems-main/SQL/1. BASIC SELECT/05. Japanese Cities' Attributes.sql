-- # Problem: https://www.hackerrank.com/challenges/japanese-cities-attributes/problem
-- # Score: 10
-- # Difficulty: Easy

SELECT *
FROM CITY
WHERE COUNTRYCODE = 'JPN';