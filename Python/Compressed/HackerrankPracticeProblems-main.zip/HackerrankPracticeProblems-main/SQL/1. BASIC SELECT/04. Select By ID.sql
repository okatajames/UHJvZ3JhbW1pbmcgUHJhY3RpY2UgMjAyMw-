-- # Problem: https://www.hackerrank.com/challenges/select-by-id/problem
-- # Score: 10
-- # Difficulty: Easy

SELECT *
FROM CITY
WHERE ID = 1661;