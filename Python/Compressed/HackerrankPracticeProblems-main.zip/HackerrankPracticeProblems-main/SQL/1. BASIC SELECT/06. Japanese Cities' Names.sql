-- # Problem: https://www.hackerrank.com/challenges/japanese-cities-name/problem
-- # Score: 10
-- # Difficulty: Easy

SELECT NAME
FROM CITY
WHERE COUNTRYCODE = 'JPN';