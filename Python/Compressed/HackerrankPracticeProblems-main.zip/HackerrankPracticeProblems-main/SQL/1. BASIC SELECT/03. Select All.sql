-- # Problem: https://www.hackerrank.com/challenges/select-all-sql/problem
-- # Score: 10
-- # Difficulty: Easy

SELECT *
FROM CITY;