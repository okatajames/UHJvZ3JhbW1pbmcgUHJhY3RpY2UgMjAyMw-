-- # Problem: https://www.hackerrank.com/challenges/weather-observation-station-1/problem
-- # Score: 15
-- # Difficulty: Easy

SELECT CITY, STATE FROM STATION;