-- # Problem: https://www.hackerrank.com/challenges/revising-aggregations-sum/problem
-- # Score: 10
-- # Difficulty: Easy


SELECT SUM(Population)
FROM City
WHERE District = 'California';