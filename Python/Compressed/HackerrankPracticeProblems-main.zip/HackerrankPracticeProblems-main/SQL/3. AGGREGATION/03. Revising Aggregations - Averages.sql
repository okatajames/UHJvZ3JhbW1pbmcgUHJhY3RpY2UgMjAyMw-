-- # Problem: https://www.hackerrank.com/challenges/revising-aggregations-the-average-function/problem
-- # Score: 10
-- # Difficulty: Easy


SELECT AVG(Population)
FROM City
WHERE District = 'California';