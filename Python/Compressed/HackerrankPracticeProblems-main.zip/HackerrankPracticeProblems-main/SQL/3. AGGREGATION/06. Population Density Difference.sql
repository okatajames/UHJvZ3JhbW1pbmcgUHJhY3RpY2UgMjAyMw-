-- # Problem: https://www.hackerrank.com/challenges/population-density-difference/problem
-- # Score: 10
-- # Difficulty: Easy


SELECT MAX(Population) - MIN(Population)
FROM City;