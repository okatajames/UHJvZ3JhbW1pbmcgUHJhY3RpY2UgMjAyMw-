-- # Problem: https://www.hackerrank.com/challenges/average-population/problem
-- # Score: 10
-- # Difficulty: Easy


SELECT ROUND(AVG(Population))
FROM City;