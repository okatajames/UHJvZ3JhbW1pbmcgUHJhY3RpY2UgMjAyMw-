-- # Problem: https://www.hackerrank.com/challenges/revising-aggregations-the-count-function/problem
-- # Score: 10
-- # Difficulty: Easy

SELECT COUNT(*)
FROM City
WHERE Population > 100000;