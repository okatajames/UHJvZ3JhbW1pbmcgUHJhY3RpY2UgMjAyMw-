# -*- coding: utf-8 -*-

def main():
    print("Hello Python!")

if __name__ == "__main__":
    main()
