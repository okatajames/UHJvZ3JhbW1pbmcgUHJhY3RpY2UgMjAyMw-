def fizz_buzz():
    # your code here


fizz_buzz()