def start_counting():
	for i in range(12):
		print(i)
	return i

start_counting()