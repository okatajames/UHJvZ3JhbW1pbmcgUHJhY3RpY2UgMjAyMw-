# `14` Your First Loop

## 📝  Instrucciones:

1. Ejecuta este código, verás una cuenta de 0 a 9 (caracteres blancos). 

2. Corrígelo para que cuente hasta 11.

## 🔎 Importante: 

+ Hay una serie de ejercicios dedicados a listas y bucles o loops, te invitamos a realizarlos antes de continuar: [https://github.com/4GeeksAcademy/python-lists-loops-programming-exercises](https://github.com/4GeeksAcademy/python-lists-loops-programming-exercises). 

!Luego, regresa!😊