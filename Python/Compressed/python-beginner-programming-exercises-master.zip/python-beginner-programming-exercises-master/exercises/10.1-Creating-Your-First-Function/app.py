def addNumbers(a,b):
	# This is the function body. Write your code here.
  

# Do not change the code below
print(addNumbers(3,4))
