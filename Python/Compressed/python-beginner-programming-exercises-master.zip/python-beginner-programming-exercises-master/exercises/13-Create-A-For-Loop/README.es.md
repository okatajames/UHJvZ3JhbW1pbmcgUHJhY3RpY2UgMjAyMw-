# `13` Create A For Loop

Los bucles o loops son muy útiles... No tienes que reescribir las mismas líneas muchas veces.

El bucle o loop `for` te permite ejecutar el mismo código varias veces para diferentes valores.

## 📝 Instrucciones:

1. Crea una función llamada `standards_maker()`.

2. La función tiene que imprimir 300 veces la frase "Escribiré preguntas si estoy atascado".

3. Llama a la función `standards_maker()`.

## 💡 Pista:

+ Puedes usar la función `range()` para el ciclo `for`.

## 🔎 Importante:

+ Puedes leer más al respecto aquí: https://ellibrodepython.com/for-python