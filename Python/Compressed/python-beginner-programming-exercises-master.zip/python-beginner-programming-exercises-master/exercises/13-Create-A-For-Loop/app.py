def standards_maker():
    #your code here

#remember to call the function outside (here)