def standards_maker():
    #your code here
    for i in range(0, 300):
        print("I will write questions if I am stuck")

#remember to call the function outside (here)
standards_maker()