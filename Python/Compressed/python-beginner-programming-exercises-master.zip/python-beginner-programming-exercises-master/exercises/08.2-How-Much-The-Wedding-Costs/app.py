user_input = int(input('How many people are coming to your wedding?\n'))

if user_input <= 50:
    price = 4000

print('Your wedding will cost '+str(price)+' dollars')