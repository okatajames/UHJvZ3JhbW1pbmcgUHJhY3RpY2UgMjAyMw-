# `05` User Inputed Values

Otra cosa genial de las variables es que no necesitas saber su valor para poder trabajar con ellas.

Por ejemplo, justo ahora la aplicación está preguntando la edad del usuario, y luego la imprime en la cónsola.

## 📝 Instrucciones:

1. Por favor, añade 10 años al valor de la variable `age`.

## 💡 Pista:

+ Puedes buscar en Google "Como sumarle una cantidad a una variable de Python".

+ Recuerda que el contenido de la variable está siendo definido con lo que sea que el usuario coloque.