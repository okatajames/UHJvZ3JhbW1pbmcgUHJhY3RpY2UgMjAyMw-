---
tutorial: "https://www.youtube.com/watch?v=uYqMOZ-jFag"
---

# `09` Random Numbers

You can use the `randint()` function to get a random integer number. `randint()` is an inbuilt function of the **random** module in Python3.

The random module gives access to various useful functions and one of them, **randint()**,  being able to generate random numbers within a range that we pass as a parameter, for example: `randint(numMinimum, numMaximum)`.

## 📝 Instructions:

1. The code now is returning random decimal numbers, please update the function code to make it return an integer (no decimal) number between 1 and 10.