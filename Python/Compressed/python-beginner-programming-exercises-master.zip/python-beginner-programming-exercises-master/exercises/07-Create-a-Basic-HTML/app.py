a = '</title>'
b = '</html>'
c = '<head>'
d = '</body>'
e = '<html>'
f = '</head>'
g = '<title>'
h = '<body>'

# ⬆ DON'T CHANGE THE CODE ABOVE ⬆
# ↓ start coding below here ↓

