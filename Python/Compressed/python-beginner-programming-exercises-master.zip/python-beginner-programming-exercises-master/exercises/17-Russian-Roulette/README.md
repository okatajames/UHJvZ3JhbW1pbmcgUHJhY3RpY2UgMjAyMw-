# `17` Russian Roulette

Have you ever played Russian Roulette? It's super fun! If you make it (wuuuajajajaja).

The revolver gun has only 6 slots for bullets... insert one bullet in one of the slots,
spin the revolver chamber to make the game random, nobody knows the bullet position.

FIRE!!!....... are you dead?

## 📝 Instructions:

1. The game is almost working, please fill the function `fire_gun` to make the game work.

2. Compare the bullet position against the chamber position.

## 💡 Hint:

+ The function needs to return `You are dead!` or `Keep playing!` depending on the result.

+ If the bullet is at the same slot as the revolver chamber, then it will be fired (`You are dead!`).