# `17`  Russian Roulette

¿Has jugado a la ruleta rusa? ¡Es muy divertido! Si no pierdes... (¡¡¡muuuajajajaja!!!).

Un revolver tiene seis orificios para balas... inserta una bala en uno de los orificios,
gira la cámara del revolver para hacer aleatorio el juego. Nadie sabrá dónde está la bala.

¡¡¡FUEGO!!!....... ¿has muerto?

## 📝 Instrucciones:

1. El juego casi funciona, por favor completa la función `fire_gun` para hacer que el juego funcione.

2. Compara la posición de la bala contra la posición de la cámara.

## 💡 Pista:

+ La función necesita devolver `You are dead!` (Estás muerto) o `Keep playing!` (Sigue jugando) dependiendo del resultado. Si la bala está en la misma recámara que la del revolver, entonces fue disparada (You are dead!).