---
tutorial: "https://www.youtube.com/watch?v=dWWvZkaPwDw"
---

# `02` Declare Variables

Variables act as a box (container) that lets you store different types of data. This is how we set a variable:

```py
name = "Daniel"
```

## 📝 Instructions:

1. Declare a new variable with the string value "Yellow" and print the value to the console.

2. Then, print its value on the console using `print(name)`.

## 💡 Hint:

+ The name of the variable can be whatever you want, but the value inside has to be the string "Yellow".
