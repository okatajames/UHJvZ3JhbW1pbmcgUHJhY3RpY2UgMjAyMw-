# `02` Declare Variables

Las variables actúan como una caja (contenedor) que te permite almacenar distintos tipos de datos. Así es como se define una variable:

```py
name = "Daniel"
```

## 📝 Instrucciones:

1. Declara una variable con el valor "Yellow" y luego imprímelo en la consola.

2. Luego, imprime su valor en la consola usando `print(name)`.

## 💡 Pista:

+ Puedes darle el nombre que quieras a la variable, pero su valor tiene que ser el texto "Yellow".
