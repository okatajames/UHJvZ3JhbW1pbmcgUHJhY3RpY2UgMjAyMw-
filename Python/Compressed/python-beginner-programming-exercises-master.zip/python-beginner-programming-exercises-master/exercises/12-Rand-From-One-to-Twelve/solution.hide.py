import random

def get_randomInt():
	random_number = random.randrange(1,13)
	return random_number

print(get_randomInt())