import random

def get_randomInt():
	# Your code here
	return None

print(get_randomInt())