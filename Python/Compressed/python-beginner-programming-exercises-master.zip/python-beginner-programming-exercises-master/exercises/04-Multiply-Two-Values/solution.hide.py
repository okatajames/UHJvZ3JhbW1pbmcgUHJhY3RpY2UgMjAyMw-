# your code here
variables_are_cool = 2345 * 7323
print(variables_are_cool)