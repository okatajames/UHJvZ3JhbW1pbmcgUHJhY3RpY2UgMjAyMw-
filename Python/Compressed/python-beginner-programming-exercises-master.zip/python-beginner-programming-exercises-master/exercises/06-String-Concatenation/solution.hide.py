# Set the values for my_var1 and my_var2 here
my_var1 = "Hello"
my_var2 = "World"

## Don't change below this line
the_new_string = my_var1+' '+my_var2
print(the_new_string)