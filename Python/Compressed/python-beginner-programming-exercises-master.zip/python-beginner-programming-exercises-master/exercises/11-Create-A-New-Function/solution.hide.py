import random

# your code here
def generate_random():
    result = random.randint(0,9)
    return result