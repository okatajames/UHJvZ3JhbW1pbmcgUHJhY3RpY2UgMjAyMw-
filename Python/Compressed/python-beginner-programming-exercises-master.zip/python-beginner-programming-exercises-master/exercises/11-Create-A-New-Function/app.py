import random

# your code here