# `03` Print Variables in The Console

También puedes usar la función **print** para imprimir variables en la consola. Es una excelente forma de verificar su valor actual, así:

```py
my_super_variable = 'hello'
print(my_super_variable)
```

## 📝 Instrucciones:

1. Declara una nueva variable llamada `color` y asígnale el valor `red`.

2. Luego, imprime su valor en la consola (puede que tengas que desplazarte en la consola para poder verlo).
