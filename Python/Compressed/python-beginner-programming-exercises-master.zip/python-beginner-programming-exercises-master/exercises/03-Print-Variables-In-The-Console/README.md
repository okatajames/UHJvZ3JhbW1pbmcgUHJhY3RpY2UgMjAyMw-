---
tutorial: "https://www.youtube.com/watch?v=Ki1LaUKhPgU"
---

# `03` Print the Variables in the console

You can also use the **print** function to print variables in the console. It's a great way to check their current value, like this:

```py
my_super_variable = 'hello'
print(my_super_variable)
```

## 📝 Instructions:

1. Declare a new variable called `color` and assign the value `red` to it.

2. Then, print its value on the console (you may have to scroll up in the terminal to see it!).
