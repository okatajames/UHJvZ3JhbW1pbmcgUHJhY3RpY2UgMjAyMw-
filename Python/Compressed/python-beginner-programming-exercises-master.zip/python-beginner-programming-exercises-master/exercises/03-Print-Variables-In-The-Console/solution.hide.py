#your code here

color = "red"
print(color)