# TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

By accessing Breathe Code we assume you accept these terms and conditions. Do not continue to use Breathe Code's content, applications or tutorials if you do not agree to take all of the terms and conditions stated on this page.

Unless otherwise stated, Breathe Code and/or its licensors own the intellectual property rights for all material on Breathe Code. All intellectual property rights are reserved. You may access this from Breathe Code for your own personal use subjected to restrictions set in these terms and conditions.

You must not:

*   Republish material from Breathe Code
*   Sell, rent or sub-license material from Breathe Code
*   Reproduce, duplicate or copy material from Breathe Code
*   Redistribute content from Breathe Code

You can read the full version of Breathe Code's terms and conditions here: [Terms and Conditions](http://breatheco.de/terms-and-conditions)
