<p align="center"><img width=12.5% src="https://github.com/vipings/practice_python/blob/logo-add/logo.png"></p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

# Practice Python Exercise with Jupyter Notebooks
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
[![CircleCI](https://circleci.com/gh/vipings/practice_python.svg?style=shield)](https://circleci.com/gh/vipings/practice_python)
![Contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg)
[![Packagist](https://img.shields.io/packagist/l/doctrine/orm.svg)](https://github.com/vipings/practice_python/blob/exercise8/LICENSE)


## Basic Overview

This repository contains solutions from practicepython.org. The exercises are done in Jupyter notebook. This is work in progess, I would be adding more examples over time.

<br>

## How to Use this Exercises

- Install and set up Python 3 Environment. I would suggest to set up with [Anaconda](https://docs.continuum.io/anaconda/install/).  

- `git clone https://github.com/vipings/practice_python.git `  

- `cd practice_python` 

-  [Start Jupyter Notebook](http://jupyter-notebook-beginner-guide.readthedocs.io/en/latest/execute.html)

- Contribute back. :smiley:

## Happy Learning !! :smiley: :+1:

<br>
&nbsp;&nbsp;
