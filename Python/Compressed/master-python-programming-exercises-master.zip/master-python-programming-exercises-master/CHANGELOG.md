# Sep 16

Niza Vera will be adding 13 exercises from [this Mastering Python Lesson in Repl.it](https://repl.it/classroom/invite/avFe7Od)

```bash
9.1. Sets: Number of distinct
9.2. Sets: Number of common
9.3. Sets: Intersection
9.4. Sets: Seen before
9.5. Sets: Guess the number
A.1. Dicts: Number of occurrences
A.2. Dicts: Synonyms
A.3. Dicts: Elections
A.4. Dicts: Most frequent word
A.5. Dicts: Access rights
A.6. Dicts: Countries and cities
A.7. Dicts: Frequency analysis
A.8. Dicts: English-Latin dictionary
```
