# `011` last two digits

## 📝 Instrucciones:

1. Completa la función `last_two_digits()` para que dado un número entero mayor que `9`, imprima sus últimos dos dígitos.

## Ejemplo de entrada:

```py
last_two_digits(1234)
```

## Ejemplo de salida:

```py
34
```
## 💡 Pistas:

+ Si no sabes por donde comenzar este ejercicio, por favor, revisa la teoría en esta lección: https://snakify.org/lessons/integer_float_numbers/

+ También puedes intentar paso a paso con trozos de la teoría: https://snakify.org/lessons/integer_float_numbers/steps/1/