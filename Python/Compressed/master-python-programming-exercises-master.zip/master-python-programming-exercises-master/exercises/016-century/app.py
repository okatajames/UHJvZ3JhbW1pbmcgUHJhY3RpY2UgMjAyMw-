#Complete the function to return the respective number of the century
#HINT: You may need to import the math module.

def century(year):
  return None



#Invoke the function with any given year. 
print(century())