# `22` Integral

Dado un número integral n, escribe un programa para generar un diccionario que contenga (i, i*i) como un número integrak entre 1 y n (ambos incluidos). Luego el programa debiese imprimir el diccionario.
Supongamos que se le entrega la siguiente entrada al programa:
8
El resultado debiese ser:
{1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64}

Pistas:
En el caso de que se le entreguen datos a la pregunta, deben asumirse como entradas de la consola. 
Considera usar dict()
