# `27` Secuencia de palabras

Escribe un programa que acepte una secuencia separada por comas como entrada e imprima las palabras en una secuencia separada por comas después de ordenarlas alfabéticamente.
Supongamos que se le entrega la siguiente entrada al programa:
without,hello,bag,world
El resultado debiese ser:
bag,hello,without,world

Pistas:
En el caso de que se le entreguen datos a la pregunta, deben considerarse como entradas de la consola.
