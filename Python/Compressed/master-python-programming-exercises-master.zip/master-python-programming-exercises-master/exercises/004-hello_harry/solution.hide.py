#Complete the function below to print the output per the example.
def hello_name(name):

    return "Hello, "+name+"!"

#Invoke the function with your name as the function's argument. 
print(hello_name("Bob"))
