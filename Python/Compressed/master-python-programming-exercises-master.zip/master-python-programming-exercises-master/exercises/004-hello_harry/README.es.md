# `004` hello Harry

## 📝 Instrucciones:

1. Completa la función `hello_name()` para que salude al usuario imprimiendo la palabra `Hello`, luego le agregue una coma, el nombre del usuario y un signo de exclamación después de él. 

*La salida de tu función debe coincidir estrictamente con la deseada, caracter por caracter. No debe haber ningún espacio entre el nombre y el signo de exclamación.* 

## Ejemplo entrada:

```py
hello_name("Harry")
```
## Ejemplo de salida:

Hello, Harry!

## 💡 Pistas:

+ Puedes usar el operador '+' para concatenar dos strings de texto. Ve la lección para más detalles.

+ Si no sabes por donde partir este ejercicio por favor, revisa la teoría en esta lección:
https://snakify.org/lessons/print_input_numbers/

+ También puedes intentar paso a paso con trozos de la teoría:
https://snakify.org/lessons/print_input_numbers/steps/1/
