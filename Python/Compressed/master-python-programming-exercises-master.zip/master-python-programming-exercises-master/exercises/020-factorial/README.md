# `020` factorial

## 📝 Instructions:

1. Create a function named `factorial()` which receives a number as parameter and returns the factorial of the given number.

## Example input:

```py
factorial(8)
```

## Example output:

+ 40320

## 💡 Hint:

+ If you don't know what a factorial is, you can check it out on this link: https://www.cuemath.com/numbers/factorial/
