# `020` factorial

## 📝 Instrucciones:

1. Crea una función llamada `factorial()` que al recibir un número como parámatro retorne su valor factorial.

## Ejemplo de entrada:

```py
factorial(8)
```

## Ejemplo de salida:

+ 40320

## 💡 Pista:

+ Si no sabes qué es un factorial, revisa la información de este link: https://factorial.mx/numero-funcion-factorial
