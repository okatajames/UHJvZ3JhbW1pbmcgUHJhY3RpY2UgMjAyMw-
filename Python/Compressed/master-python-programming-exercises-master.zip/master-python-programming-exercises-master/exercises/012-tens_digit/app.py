#Complete the function to return the tens digit of a given interger
def tens_digit(num):
  return None




#Invoke the function with any interger.
print(tens_digit())