#Complete the function to return the tens digit of a given interger
def tens_digit(num):
  return (num // 10) % 10




#Invoke the function with any interger.
print(tens_digit(123))