# `012` tens digits

## 📝 Instrucciones:

1. Completa la función `tens_digit()` para que dado un número entero, retorne sus decenas.

## Ejemplo de entrada 1:

```py
tens_digit(1234)
```

## Ejemplo de salida 1:

```py
3
```

## Ejemplo de entrada 2:

```py
tens_digit(179)
```

## Ejemplo de salida 2:

```py
7
```

## 💡 Pistas:

+ Si no sabes por donde comenzar este ejercicio, por favor, revisa la teoría en esta lección: https://snakify.org/lessons/integer_float_numbers/

+ También puedes intentar paso a paso con trozos de la teoría: https://snakify.org/lessons/integer_float_numbers/steps/1/
