# `29`Eliminar los duplicados

Escribe un programa que acepte una secuencia de palabras separadas por espacios en blanco como entrada y que imprima luego las palabras eliminando todas las duplicadas y ordenándolas alfanuméricamente.

Supongamos que se le entrega la siguiente entrada al programa:

hello world and practice makes perfect and hello world again

El resultado debería ser:

again and hello makes perfect practice world

Pistas:
En caso de que se le entregue entradas de datos a la pregunta, debe asumirse como entrada de la consola.

Usa set container para eliminar los datos duplicados automáticamente y luego usa sorted() para ordenar los datos.


