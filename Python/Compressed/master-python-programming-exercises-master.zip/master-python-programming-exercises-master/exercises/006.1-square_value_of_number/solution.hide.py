def square(num):
    return num ** 2

print(square(2))
print(square(3))