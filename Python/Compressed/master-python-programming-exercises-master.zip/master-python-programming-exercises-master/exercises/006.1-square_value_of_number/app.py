# your code here
def square(num):
    return None

print(square(6))