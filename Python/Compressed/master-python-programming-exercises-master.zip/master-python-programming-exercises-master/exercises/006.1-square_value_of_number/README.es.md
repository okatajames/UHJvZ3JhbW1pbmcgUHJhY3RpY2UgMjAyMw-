# `006.1` square value of number

## 📝 Instrucciones:

1. Escribe una función llamada `square()` que calcule el valor al cuadrado de un número

## Ejemplo de entrada:

```py
square(6)
```

## Ejemplo de salida:

```py
36
```
## 💡 Pista:

+ Usa el operador `**`.
