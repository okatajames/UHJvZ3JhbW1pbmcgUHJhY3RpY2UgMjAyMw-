# `006.1` square value of number

## 📝 Instructions

1. Write a function called `square()` that calculates the square value of a number.

## Example input:

```py
square(6)
```

## Example output:

```py
36
```

## 💡 Hint:

+ Using the `**` operator
