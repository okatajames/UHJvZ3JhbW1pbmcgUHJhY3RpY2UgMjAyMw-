# `014` digit after decimal point

## 📝 Instrucciones:

1. Completa la función `first_digit()` para que dado un número real positivo, devuelve su primer decimal (a la derecha del punto).

## Ejemplo de entrada:

```py
first_digit(1.79)
```

## Ejemplo de salida:

+ 7

## 💡 Pistas:

+ Si no sabes por donde comenzar este ejercicio, por favor, revisa la teoría en esta lección: https://snakify.org/lessons/integer_float_numbers/

+ También puedes intentar paso a paso con trozos de la teoría: https://snakify.org/lessons/integer_float_numbers/steps/1/