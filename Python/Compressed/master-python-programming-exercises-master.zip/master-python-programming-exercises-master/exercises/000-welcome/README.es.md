# Bienvenid@ a Python!

¡¡Nos estusiasma mucho tenerte aquí!! 🎉 😂

Este es el último de una serie de ejercicios publicados para practicar Python desde cero por [@alesanchezr](https://twitter.com/alesanchezr) y [4GeeksAcademy](https://4geeksacademy.com).

Si no haz completado los otros ejercicios te recomiendo que empieces por alli:

1. [Python for beginners](https://github.com/4GeeksAcademy/python-beginner-programming-exercises)

2. [Practice Looping Lists and Tuples](https://github.com/4GeeksAcademy/python-lists-loops-programming-exercises)

3. [Practice Functions](https://github.com/4GeeksAcademy/python-functions-programming-exercises)


Presiona `Next →` en la esquina superior derecha cuando quieras empezar.
