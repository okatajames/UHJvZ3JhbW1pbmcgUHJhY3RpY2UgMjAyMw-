# Welcome to Python!

We are very excited to have you here !! 🎉 😂

This is the last series of exercises of a list of Python interactive tutorials published by [@alesanchezr](https://twitter.com/alesanchezr) with [4GeeksAcademy](https://4geeksacademy.com).

If you have not completed them and you are new to javascript, I strongly recomend you start with:

1. [Python for beginners](https://github.com/4GeeksAcademy/python-beginner-programming-exercises)

2. [Practice Looping Lists and Tuples](https://github.com/4GeeksAcademy/python-lists-loops-programming-exercises)

3. [Practice Functions](https://github.com/4GeeksAcademy/python-functions-programming-exercises)

Click `Next →` on the top right of this instructions when you are ready to start.