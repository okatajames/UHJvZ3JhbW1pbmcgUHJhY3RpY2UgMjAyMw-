# `005` previous and next

## 📝 Instrucciones:

1. Completa la función `previous_next()` para que lea un número entero y devuelva sus números anteriores y siguientes. 

## Ejemplo:

```py
previous_next(179)
```

## Ejemplo de salida:

+ (178, 180)

## 💡 Pistas:

+ Puedes devolver múltiples parámetros: return a, b

+ Si no sabes por donde partir este ejercicio, por favor revisa la teoría en esta lección: https://snakify.org/lessons/print_input_numbers/

+ También puedes intentar paso a paso con trozos de la teoría: https://snakify.org/lessons/print_input_numbers/steps/1/