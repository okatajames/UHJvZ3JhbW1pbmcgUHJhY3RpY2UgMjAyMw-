#Complete the function to return the previous and next number of a given numner.".
def previous_next(num):
  return (num-1, num+1)


#Invoke the function with any interger at its argument. 
print(previous_next(179))