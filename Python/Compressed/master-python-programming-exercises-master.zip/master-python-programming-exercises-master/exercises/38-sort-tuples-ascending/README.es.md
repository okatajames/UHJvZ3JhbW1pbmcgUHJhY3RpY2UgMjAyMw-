# `38` Sort Tuples Ascending
Debe escribir un programa para ordenar las tuplas (nombre, edad, altura) por orden ascendente donde el nombre es `string`, la edad y la altura son `números`.
