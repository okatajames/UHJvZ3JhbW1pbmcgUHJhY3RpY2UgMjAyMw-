import math
def print_formula(num):
    return round(math.sqrt(2*50*num/30))

print(print_formula(5))