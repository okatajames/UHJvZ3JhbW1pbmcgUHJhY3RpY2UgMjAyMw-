# `25` Imprime la fórmula

Escribe un programa que calcule e imprima el valor de acuerdo a la fórmula dada:

Q = Square root of [(2 * C * D)/H]

A continuación encontrarás los valores fijos de C y H:
C es 50. H es 30.
D es la variable cuyos valores debiesen ser ingresados en tu 
Ejemplo:
Digamos que le sentrega la siguiente secuencia separada por coma al programa:
100,150,180
El resultado del programa debiese ser:
18,22,24

Pistas:
Si el resultado recicido es un decimal, debería rendondearse a su valor más cercano (por ejemplo, si el resultado es 26.0, debiese imprimirse como 26)
En el caso de que se le hayan entregado datos a la cuestión, deben asumirse como una entrada de la consola.
 