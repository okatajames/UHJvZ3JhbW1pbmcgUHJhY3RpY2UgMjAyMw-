def lines(text):
    return text.upper()

print(lines('Hello world'))