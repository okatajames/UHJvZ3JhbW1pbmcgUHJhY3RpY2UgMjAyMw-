# `28` Sequence of lines

Escribe un programa que acepte una secuencia de líneas como entrada y que luego imprima las líneas convirtiendo todos los caracteres en mayúscula.

Supongamos le entregamos la siguiente entrada al programa:
Hello world
Practice makes perfect
El resultado debería ser este:
HELLO WORLD
PRACTICE MAKES PERFECT

Pistas:
En caso de que se le pasen entradas de datos a la pregunta, deben asumirse como entradas de la consola.
