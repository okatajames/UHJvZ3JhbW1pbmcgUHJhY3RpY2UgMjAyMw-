values=input("")
l=values.split(",")
t=tuple(l)
print (l)
print (t)

# 
values=input("")
t=tuple(values.split(','))
print(t)