# `23` Lista y tupla

Escribe un programa que acepte una secuencia de números separados por comas desde la consola y genere una lista y una tupla que contenga todos los números.
Supongamos que se le entrega la siguiente entrada al programa:
34,67,55,33,12,98
El resultado debiese ser:
['34', '67', '55', '33', '12', '98']
('34', '67', '55', '33', '12', '98')

Pistas:
En el caso de que se le entreguen entradas de datos a la pregunta, deben asumirse como entradas de la consola. 
Usa el método tuple() para convertir la lista en una tupla.
