# `26` Array de dos dimensiones

Escribe un progrsms que reciba dos dígitos X,Y como entrada y genere un array de dos dimensiones. El valor del elemento en la fila i-th y en la columna j-th del array debiese ser i*j.
Nota: i=0,1.., X-1; j=0,1,¡­Y-1.
Ejemplo:
Supongamos que se le entregan lasa siguientes entradas al programa:
3,5
Entonces, el resultado del programa debería ser:
[[0, 0, 0, 0, 0], [0, 1, 2, 3, 4], [0, 2, 4, 6, 8]] 

Pistas:
Nota: En el caso de que se le entreguen datos a la cuestión, debe asumirse como una entrada de la consola en un formulario separado por comas.

