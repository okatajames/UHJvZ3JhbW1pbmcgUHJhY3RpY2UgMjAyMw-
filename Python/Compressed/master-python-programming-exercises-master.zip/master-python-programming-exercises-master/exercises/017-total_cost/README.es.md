# `017` total cost

## 📝 Instrucciones:

1. Un cupcake (quequito) cuesta `D` dólares y `C` centavos. Escribe un función `total_cost()` para determinar cuántos dólares y centavos debería pagar una persona por `N` cupcakes. *La función recibe tres números: `D`, `C`, `N` y debería devolver dos números: costo total en dólares y los centavos*

## Ejemplo de entrada:

```py
total_cost(10,15,2)
```

## Ejemplo de salida:

+ (20, 30)

## 💡 Pistas:

+ Si no sabes por donde comenzar este ejercicio, por favor, revisa la teoría en esta lección: https://snakify.org/lessons/integer_float_numbers/

+ También puedes intentar paso a paso con trozos de la teoría: https://snakify.org/lessons/integer_float_numbers/steps/1/