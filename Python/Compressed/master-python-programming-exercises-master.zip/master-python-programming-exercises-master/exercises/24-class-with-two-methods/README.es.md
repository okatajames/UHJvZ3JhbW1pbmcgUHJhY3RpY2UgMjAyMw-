# `24` Una clase con dos métodos

Define una clase que tenga al menos dos métodos:
Define a class which has at least two methods:
getString: obtener un string desde la entrada de la consola.
printString: imprimir el string en mayúscula.
Por favor incluye una función simple de prueba para probar los métodos de la clase.

Pistas:
Usa el método __init__ para construir algunos parámetros.