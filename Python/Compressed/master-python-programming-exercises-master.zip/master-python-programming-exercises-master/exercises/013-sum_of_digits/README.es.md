# `013` sum of digits

## 📝 Instrucciones:

1. Completa la función `digits_sum()` para que dado un número de tres dígitos, retorne la suma de sus dígitos.

## Ejemplo de entrada:
 
```py
 digits_sum(123)
 ```

## Ejemplo de salida:

```py
6
```

## 💡 Pistas:

+ Si no sabes por donde comenzar este ejercicio, por favor, revisa la teoría en esta lección: https://snakify.org/lessons/integer_float_numbers/

+ También puedes intentar paso a paso con trozos de la teoría: https://snakify.org/lessons/integer_float_numbers/steps/1/