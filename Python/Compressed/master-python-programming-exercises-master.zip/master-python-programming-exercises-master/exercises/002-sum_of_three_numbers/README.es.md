# `002` sum of three numbers

## 📝 Instrucciones:

1. Teniendo tres números de entrada, imprime su suma. Cada número va en una línea aparte.

## Ejemplo de entrada:

```py
2
3
6
```

## Ejemplo de salida:

```py
11
```

