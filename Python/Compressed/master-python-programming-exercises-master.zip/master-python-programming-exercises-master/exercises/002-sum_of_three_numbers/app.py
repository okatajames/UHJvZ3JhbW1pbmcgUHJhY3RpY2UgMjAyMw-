# Sum all three input numbers and print on the console the result
first_number = int(input("First input"))
second_number = int(input("Second input"))
third_number = int(input("Third input"))
# print here the sum of three inputs

print(first_number+second_number)