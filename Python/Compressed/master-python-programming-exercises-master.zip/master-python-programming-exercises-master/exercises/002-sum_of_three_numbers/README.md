# `002` sum of three numbers

## 📝 Instructions:

1. Taking 3 numbers from the input, print their sum. Every number is given on a separate line.

## Example input:

```py
2
3
6
```

## Example output:

```py
11
```

