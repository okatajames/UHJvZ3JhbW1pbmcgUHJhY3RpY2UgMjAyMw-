#Complete the function to return the area of the triangle.
def area_of_triangle(arg1, arg2):
    #your code here, please remove the "None" 
    return arg1 * arg2 / 2

# Testing your function
print(area_of_triangle(3, 5))