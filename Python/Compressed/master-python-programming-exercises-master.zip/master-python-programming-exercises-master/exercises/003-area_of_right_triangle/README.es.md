# `003` area of right triangle

## 📝 Instrucciones:

1. Completa la función `area_of_triangle()` para que que tome el largo de la base y la altura de un triángulo rectángulo e imprima su área. Cada número es dado en una línea por separado.

![Imagen descriptiva](http://i.imgur.com/6EkzVxA.jpg)

## Ejemplo:

```py
area_of_triangle(3,5)
    print(7.5)
```
## 💡 Pistas:

+ Si no sabes por donde empezar este ejercicio, por favor, revisa la teoría en esta lección: https://snakify.org/lessons/print_input_numbers/

+ También puedes intentar paso a paso con trozos de la teoría: https://snakify.org/lessons/print_input_numbers/steps/1/