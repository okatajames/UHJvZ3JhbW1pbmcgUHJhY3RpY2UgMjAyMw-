## Write a FizzBuzz implementation in C.

for multiples of three, Print “Fizz” instead of the number, and for multiples of five, Print “Buzz.” Print “FizzBuzz” for numbers that are multiples of three and five.

number/3 = 0 -> Print Fizz
number/5 = 0 -> Print Buzz
number/3 & number/5 = 0 -> Print FizzBuzz


