
## IP-EXERCISE 2
* Calculate the discount for the wedding packages.

1. Offer 10% discounts from hotel charge for wedding packages in festive season.

2. Discount is valid only number of guests > 200

    ```Hotel charge = number of guests * charge per guest```

3. Calculate the discount considering number of guests

    ```float getDiscountPrice(int noOfGuests, float chargePerGuest);```

4. getAmount(): to calculate the amount to be paid.

    ```float getAmount(int noOfGuests, float chargePerGuest, float discount);```
    
    Formula: ```Amount to be paid = (no of guests * charge per guest) – discount)```

5. main():

    * Read the number of guests
    * Read the charge per guest
    * display the discount
    * amount to be paid


## Output
```
Enter number of guests:
Enter charge per guest:
Discount:
Amount to be paid:
```

____

* Note: I didn't had access to most of the IP module questions. So, I got them from [https://hasiyablog.wordpress.com/atsliit/](https://hasiyablog.wordpress.com/atsliit/).