
## IP-EXERCISE 5
* Rating calculator on a scale of 1 to 5.

* Store the number of responces from their customers using an array.
    * Array element 0 = Scale 1
    * Array element 1 = Scale 2
    * ...

* Declare an one dimensional array called **rate** with the size of **5**.
* Initialize all the array elements to zero.
* Read the ratings(number from 1 to 5) from the keyboard
    * Store responses for each rate in the array.
    * You should read the responces 5 times.

* If the user input a number less than 1 or greater than 5, display an appropriate error message.

* Display the number of responses for each rating at the end.


## Output
```
Please enter your rating: 4
Please enter your rating: 3
Please enter your rating: 5
Please enter your rating: 1
Please enter your rating: 3

Rating   Number of responses
1        1
2        0
3        2
4        1
5        1

```

____

* Note: I didn't had access to most of the IP module questions. So, I got them from [https://hasiyablog.wordpress.com/atsliit/](https://hasiyablog.wordpress.com/atsliit/).