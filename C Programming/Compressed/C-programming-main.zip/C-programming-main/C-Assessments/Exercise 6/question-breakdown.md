
## IP-EXERCISE 6
* The aptitude test...

* 10 applicants at a time. Marks are given within range 0-100.
    * Greater or less than that display error msg.
        * Re enter marks

* Those who scored **more than the average mark** will be qualified to enter the university.
    * Others have to take the test again.

* Write a C program to enter marks in an array and find the marks which will be qualified.

    * Declare an **integer array** called **testMarks of size 10**.
    * **Initialize** all the array elements to **-1**.
    * Read the marks from keyboard and store then in the array.


## Output
```
Input mark 1: 92
Input mark 2: 110
Invalid mark. Please re-enter.
Input mark 2: 76
....................................
....................................
Input mark 10: 84

Input array:
92 76 80 48 66 89 61 56 92 84
Output:
Passed marks: 92 76 80 89 92 84

```

____

* Note: I didn't had access to most of the IP module questions. So, I got them from [https://hasiyablog.wordpress.com/atsliit/](https://hasiyablog.wordpress.com/atsliit/).