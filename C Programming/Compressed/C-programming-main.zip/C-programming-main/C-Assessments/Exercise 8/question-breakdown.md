
## IP-EXERCISE 8
* Salaries Tracker

* Declare a double array called salaries of size 5.
    * Initialize all the array elements to -1.

* **Input the salaries of 5 employees** and **store them in the array**.
    * If the user input a **negative value**, display an **error message and ask to re-enter the salary**.

* Give a **10% increment** for the employees whose salaries are **below 10000.00**.
    * Then, Update the array accordingly.

* Display the employee number and the new salaries in the following format (given in the output).


## Output
```
Input salary of employee 1: 20000.00
Input salary of employee 2: 15000.00
Input salary of employee 3: -1200
Please re-enter the amount.
Input salary of employee 3: 75000.00
...................................
...................................


Employee number     Salary
1                   xxxxxx
2                   xxxxxx
```

____

* Note: I didn't had access to most of the IP module questions. So, I got them from [https://hasiyablog.wordpress.com/atsliit/](https://hasiyablog.wordpress.com/atsliit/).