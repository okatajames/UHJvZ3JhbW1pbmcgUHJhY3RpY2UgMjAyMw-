
## Question

You are asked to write a C program to calculate the increment given for employees.

Write a function called calcIncrement() to calculate and return the increment given for employees. The incrementamount is 10% of the salary. Increment is given only to the employees who worked more than 2 years. Function protype is given below.

float calcIcrement(float salary, int noofYearsWorked);

Write a function called calcTotalSalary() to calculate the total salary.
(total salary = salary + increment).

float calcTotalSalary(float salary, float increment);

In your main function, enter the salary of an employee and the number of years worked from the keyboard. Display the increment and total salary as follows using the functions created.

```
Enter salary :
Enter number of years worked :
Increment :
Total salary :
```