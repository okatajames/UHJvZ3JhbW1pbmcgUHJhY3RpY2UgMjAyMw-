
## IP-EXERCISE 1: Calculate the increment given for employees:

1. Write a function called **calcIncrement()** to calculate and return the increment given for employees.

    ```float calcIcrement(float salary, int noofYearsWorked);```

2. The incrementamount is 10% of the salary.

3. Increment is given only to the employees who worked more than 2 years.

4. Write a function called **calcTotalSalary()** to calculate the total salary.

    ```float calcTotalSalary(float salary, float increment);```

5. In your **main()** func

    * Enter the salary of an employee and the number of years worked from the keyboard.
    * Display the increment
    * Display the total salary


## Output
```
Enter salary :
Enter number of years worked :
Increment :
Total salary :
```

____

* Note: I didn't had access to most of the IP module questions. So, I got them from [https://hasiyablog.wordpress.com/atsliit/](https://hasiyablog.wordpress.com/atsliit/).