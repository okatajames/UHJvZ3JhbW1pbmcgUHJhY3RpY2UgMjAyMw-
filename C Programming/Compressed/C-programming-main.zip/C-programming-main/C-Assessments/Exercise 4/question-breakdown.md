
## IP-EXERCISE 4
* Price calculator.


* Unit price of three items are listed below.

    | ITEM        | UNIT PRICE(RS) |
    | ----------- | -----------    |
    | 1           | 100.00         |
    | 2           | 200.00         |
    | 3           | 300.00         |


1. totalCost(): find and return the total cost

    `calculateTotalCost(int itemNo, int quantity);`
    
    Formula: `Total cost = unit price * quantity`

2. printDetails(): print the item number, quantity, and the total cost.

    `void printDetails(int itemNo, int quantity, float totalCost);`

3. main()

    * input item number
    * input quantity purchased
    * printDetails()


## Output
```
Enter Item Number: 
Enter Quantity Purchased: 

================== RESULTS ==================

Item Number: 
Quantity: 
Total Cost: 
```

____

* Note: I didn't had access to most of the IP module questions. So, I got them from [https://hasiyablog.wordpress.com/atsliit/](https://hasiyablog.wordpress.com/atsliit/).