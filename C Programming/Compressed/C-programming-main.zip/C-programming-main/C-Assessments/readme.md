
## C-Assessments 📰

* C Assessment answers by [Shalinda Fernando](https://github.com/shafdo).

* You can find more infomation on a personal repo I created: [https://github.com/shafdo/IP-PREP](https://github.com/shafdo/IP-PREP)

* My GitHub profile: [https://github.com/shafdo](https://github.com/shafdo)