#include <stdio.h>
#include <stdlib.h>


int main()
{
    int n;

    printf("Enter n: ");
    scanf(" %d",&n);
    int sum = n*(n+1)*0.5;
    printf("SUM :  %d: ", sum );

    return 0;
}
