#include<stdio.h>

int main()
{	
	printf("Welcome\nto\nSLIIT");

	return 0;
}