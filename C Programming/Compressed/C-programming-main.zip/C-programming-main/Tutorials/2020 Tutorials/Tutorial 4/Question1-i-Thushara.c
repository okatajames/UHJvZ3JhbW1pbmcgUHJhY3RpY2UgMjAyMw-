#include<stdio.h>

int main()
{	
	printf("Thushara");

	return 0;
}