#include <stdio.h>

int main() {
    int i = 10;

    // while loop for print numbers
    while (i <= 20) {
        printf("%d\n", i);
        i++;

    }
    return 0;
} // end of main