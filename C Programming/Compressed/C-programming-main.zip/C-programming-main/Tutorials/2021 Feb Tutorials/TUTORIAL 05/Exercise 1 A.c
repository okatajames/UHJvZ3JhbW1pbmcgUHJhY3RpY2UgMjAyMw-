//Exercise 1: Practice to write while loops

#include <stdio.h>
int main(void)
{//function main begins
	int counter=10;// initialization
	while (counter<=20){//repetition condition
		
		printf("%d\n",counter);// display counter
		++counter;// increment
		
	}//end while 
	  
	  
	  return 0;
	  
}//end main of the function
