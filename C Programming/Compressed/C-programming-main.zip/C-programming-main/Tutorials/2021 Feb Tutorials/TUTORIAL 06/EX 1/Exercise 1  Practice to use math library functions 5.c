/*Exercise 1  Practice to use math library functions 
Show the value of x after each of the following statements is performed:
i. x = floor(7.5)
ii. x = ceil (0.0)
iii. x = ceil (-6.4)
iv. x = log10(100.0)
v. x = ceil (floor (-5.5)) */

#include <stdio.h>
#include <math.h>
int main(void)
{
	printf("%.2f",ceil (floor (-5.5)));

	return 0;
}//end of the main function
