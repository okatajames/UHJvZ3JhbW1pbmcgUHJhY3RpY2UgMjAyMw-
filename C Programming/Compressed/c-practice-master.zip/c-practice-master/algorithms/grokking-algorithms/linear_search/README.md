## Linear Search

Linear Search is a simple searching algorithm. Each element in the list is checked until the desired
result is retrieved or the end of the list has been reached.


#### Linear Search Run Time

Linear Search run time is O(n):

|     Input     | Worse Case Run Time  |
|:-------------:|:--------------------:|
|	   100  	|         100  		   |
| 4,000,000,000 |    4,000,000,000     |
