/*
 * Write, compile, and run a C program that creates a binary file name grades.bin 
 * and writes the following five lines of data to the file:
 *
 * 	90.3    92.7    90.3    99.8
 * 	85.3    90.5    87.3    90.8
 * 	93.2    88.4    93.8    75.6
 * 	82.4    95.6    78.2    90.0
 * 	93.5    80.2    92.9    94.4
 *
 * Using the data in the grades.bin file created - write, compile, and run a C
 * program that reads, computes, and displays the average of each group of four
 * grades.
 *
 */

#include <stdio.h>

int
main()
{
	return 0;
}
