/*
 * main.h
 */

#define len(array) (sizeof(array)/sizeof(array[0]))

#define global_variable static

global_variable const int Size = 5;

