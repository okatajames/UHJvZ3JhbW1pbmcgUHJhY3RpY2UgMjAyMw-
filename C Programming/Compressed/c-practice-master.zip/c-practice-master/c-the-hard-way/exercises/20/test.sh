set -e

make clean
make

./ex20 1 82 39 44 1 2 3 4 9 8 1 10 11
