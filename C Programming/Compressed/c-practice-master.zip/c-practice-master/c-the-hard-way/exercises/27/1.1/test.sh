make clean
make

./ex27
