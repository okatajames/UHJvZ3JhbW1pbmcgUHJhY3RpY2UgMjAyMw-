# c-practrice
A collection of C/C++ practice problems.
