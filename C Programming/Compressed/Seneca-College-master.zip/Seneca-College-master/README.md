# Seneca-College
Projects developed at Seneca College

IPC144 - Programming Fundamentals Using C <br>
OOP244 - Introduction to Object-Oriented Programming (using C++) <br>
WEB222 - Web Programming Principles <br>
OOP345 - Object-Oriented Software Development Using C++ <br>
DBS311 - Advanced Database Services <br>
SYD366 - Software Analysis and Design I <br>
WEB322 - Web Programming Tools and Frameworks 
