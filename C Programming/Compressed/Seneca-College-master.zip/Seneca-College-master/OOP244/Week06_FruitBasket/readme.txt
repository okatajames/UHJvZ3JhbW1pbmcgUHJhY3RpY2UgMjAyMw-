Workshop goals: work with a class that holds dynamic resources as well as static ones.
In addition to having regular member functions, this class willalso be copied. 
Copying their data members will involve the use of copy constructors and assignment operators. 
The class used in this workshop is the Basket class for which different fruit baskets are produced.
