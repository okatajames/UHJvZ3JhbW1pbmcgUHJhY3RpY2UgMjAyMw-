Workshop goal: implement an abstract definition of behavior for a specific type. 
Establish the following class hierarchy: the Employee class will be an abstract base class from where the Doctor and Engineer classes will be derived.
