wordStat is a program that reads a text file from standard input and analyzes and reports the number of words and their occurrences in the text file.
