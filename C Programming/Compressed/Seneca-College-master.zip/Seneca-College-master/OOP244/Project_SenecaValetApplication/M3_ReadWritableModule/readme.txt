The app needs to have an abstract base class to make Car and Motorcycle classes read/writable.
ReadWritable class should force Read and Write capability to all its derived classes in two different ways: Comma Separated Values or Screen format.
