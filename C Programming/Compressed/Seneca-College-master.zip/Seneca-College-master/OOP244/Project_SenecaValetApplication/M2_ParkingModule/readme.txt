Main structure of the application that gives the user all the options needed for managing a valet parking - early version
It needs the Menu module (M1) to run.
