Car and Motorcycle classes are inherited from the Vehicle class before the final stage of development of this project.
They need ReadWritable (M3) and Vehicle (M4) modules to run.
