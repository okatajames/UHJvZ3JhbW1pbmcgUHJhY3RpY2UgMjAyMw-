Project goal: create an application that keeps track of a Valet Parking that can park Cars, Motorcycles and Busses in a parking and retrieve them back when requested.
Project divided into 6 milestones.
