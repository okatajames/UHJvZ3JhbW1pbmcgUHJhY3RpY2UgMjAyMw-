Class Vehicle derived from the ReadWritable Class in milestone 3 - need to create a class that encapsulates a Vehicle to be parked in parking spot and can be retrieved when it is needed to be returned to the customer.
Needs ReadWritable module to run.
