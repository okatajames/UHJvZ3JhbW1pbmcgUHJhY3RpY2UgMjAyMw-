Workshop goals: work with classes that make up hierarchal structure.
The base or parent class will be a Vehicle that holds common attributes of a vehicle then the child class Car will be derived from the parent class.
In addition to this hierarchy, custom input/output operators for these classes are defined.
