Workshop goal: work with a templated class that will allow for its member data and functions to operate on types supplied through a parameter list.
The class will be a container similar to an array.
It will hold an array of numbers of unknown tipe and perform some operations on them via operator overloads.
