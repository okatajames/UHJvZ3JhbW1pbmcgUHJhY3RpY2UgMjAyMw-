Workshop goal: write code to practice operator overloading to implement Ships and Engine classes.
