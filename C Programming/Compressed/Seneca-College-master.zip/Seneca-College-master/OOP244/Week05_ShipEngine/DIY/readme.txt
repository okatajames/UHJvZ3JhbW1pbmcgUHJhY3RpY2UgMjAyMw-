Te class Ship is updated: no limit for the array of engines, representing the engines in the ship; no limit for the array representing the type of the
ship (memory is dynamically allocated).
