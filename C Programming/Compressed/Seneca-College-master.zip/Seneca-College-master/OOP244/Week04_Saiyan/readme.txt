Workshop goal: code a class that represents a Saiyan (A race of aliens inspired from DBZ anime show) and control their powers and fate through various
member functions.
