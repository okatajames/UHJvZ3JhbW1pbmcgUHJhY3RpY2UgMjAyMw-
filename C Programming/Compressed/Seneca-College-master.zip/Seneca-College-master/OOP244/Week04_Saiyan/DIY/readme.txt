The Saiyan module is updated to include a new data data member.
I allocated memory in the constructor and freed memory in the desctructor; also, made sure set function does not cause memory leak.
