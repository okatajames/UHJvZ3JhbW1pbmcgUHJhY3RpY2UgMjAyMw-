Workshop goal: use classes, access levels and member functions to create encapsulated objects. 
I did it via the use of a class that represents a Train carrying Cargo.
