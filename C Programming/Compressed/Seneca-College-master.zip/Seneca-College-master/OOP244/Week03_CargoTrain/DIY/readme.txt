The train module is updated to provide a stronger sense of encapsulation while also creating additional functions.
