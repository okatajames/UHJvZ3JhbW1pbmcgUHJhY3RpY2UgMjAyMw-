Workshop goal: use references to modify content of variables in other scopes, overload functions and allocate memory at run-time and deallocate that memory when it is no longer required. 
I did it via the use of a struct that represents a Gift.
