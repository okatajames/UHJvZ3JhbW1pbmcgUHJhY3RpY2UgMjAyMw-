The Gift module is updated to include a new struct called Wrapping in order to allow the Gift to be decorated with colourful paper.
