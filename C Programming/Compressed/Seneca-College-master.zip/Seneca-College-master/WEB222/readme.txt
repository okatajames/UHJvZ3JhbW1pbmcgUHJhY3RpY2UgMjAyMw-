Web development principles
Javascript, .json, CSS, HTML, DOM tree
