#include<stdio.h>
main()
{
     int age=20;
     char name[]="Rohit Krishna"; // is same as char name[14]="Rohit Krishna"; an extra number for termination
     printf("%s is %d years old",name,age);
     getch();
}
