#include<stdio.h>
#include<conio.h>

int main(void)
{
	printf("%d",multiply(6,2));
}
int multiply(int a, int b)
{
	return a*b;
}

