#include<stdio.h>
#include<conio.h>
main()
{
     int i;
     char c;
     printf("ASCII table\n");
     for(i=0;i<=256;i++)
     {
          printf("%c ",c);
          c++;
     }
     getch();
}
