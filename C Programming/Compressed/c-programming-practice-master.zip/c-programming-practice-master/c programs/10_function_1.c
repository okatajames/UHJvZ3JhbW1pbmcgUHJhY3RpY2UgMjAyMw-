#include<stdio.h>
 int func(int variable)
 {
     return variable*2;
 }
 
 int main()
 {
     printf("%d",func(4));
     getch();
 }
 

  

