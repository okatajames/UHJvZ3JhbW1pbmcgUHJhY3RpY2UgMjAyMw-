#include<stdio.h>
int main(void)
{
	printf("BBB    EEEEE   FFFFF\n");
	printf("B  B   E       F    \n");
	printf("B  B   E       F    \n");
	printf("BBB    EEE     FFF  \n");
	printf("B  B   E       F    \n");
	printf("B  B   E       F    \n");
	printf("BBB    EEEEE   F    \n");
}
