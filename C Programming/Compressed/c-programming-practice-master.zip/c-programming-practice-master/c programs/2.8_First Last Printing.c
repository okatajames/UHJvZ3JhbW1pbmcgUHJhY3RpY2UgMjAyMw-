#include<stdio.h>
int main(void)
{
	int i1,i2,i3,i4,i5,i6,i7,i8,i9,i10;
	printf("Enter 10 integers:");
	scanf("%d %d %d %d %d %d %d %d %d %d",&i1,&i2,&i3,&i4,&i5,&i6,&i7,&i8,&i9,&i10);
	printf("\nYour numbers are:\n");
	printf("%d %d\n",i1,i10);
	printf("%d %d\n",i2,i9);
	printf("%d %d\n",i3,i8);
	printf("%d %d\n",i4,i7);
	printf("%d %d",i5,i6);
}
