#include<stdio.h>

#define PROD(a,b) (a)*(b)
#define SQUARE(a) (a)*(a)

int main(void)
{
	printf("%d",SQUARE(51));
}
