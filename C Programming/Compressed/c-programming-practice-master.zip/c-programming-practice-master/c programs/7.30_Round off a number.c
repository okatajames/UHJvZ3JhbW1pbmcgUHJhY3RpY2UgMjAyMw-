#include <stdio.h>
#include <math.h>
 int main()
{
       
	   float a,b;
	   printf("Enter a num:");
	   scanf("%f",&a);
	   b=round(a);
	   printf("%f",b);
}
