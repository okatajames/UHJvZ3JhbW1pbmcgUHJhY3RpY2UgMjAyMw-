#include<stdio.h>
#include<conio.h>
main()
{    
     
     float temp,c=0,w=0;
     char q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12;
     printf("Welcome to the quiz. Test your knowledge by attempting these 11 questions.Press a key to begin..............\n");
     getch();
     printf("\nOnce you read the question press the appropriate option letter.Press a key when you are ready.\n");
     getch();
     system("cls");
//Question 1
     printf("\n1.Some months have 30 days, some months have 31 days, but how many have 28 days?");
     printf("  a)One\n  b)Five\n  c)Eleven\n  d)Twelve\n  e)None of the above ");
     scanf("%s",&q1);
     if(q1=='d'|| q1=='D')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 2
     printf("\n2.Take two apples from three apples. How many do you have?");
     printf("  \n  a)One\n  b)Two\n  c)Three\n  d)Four\n  e)None of the above ");
     scanf("%s",&q2);
     if(q2=='b'|| q2=='B')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 3
     printf("\n3.If you enter with only a match into a COLD and DARK room which has an oil lamp, an oil heater and a candle in it. Which one do you light first?");
     printf("  \n  a)Candle\n  b)Match\n  c)Oil heater\n  d)Oil lantern\n  e)None of the above ");
     scanf("%s",&q3);
     if(q3=='b'|| q3=='B')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 4
     printf("\n4.You are participating in a race. You overtake the second person. What position are you in?");
     printf("  \n  a)First\n  b)Second\n  c)Third\n  d)Last\n  e)None of the above ");
     scanf("%s",&q4);
     if(q4=='b'|| q4=='B')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 5
     printf("\n5.A mute person walks into a shop and wants to buy a toothbrush. By imitating the action of brushing his teeth, after successfully expressing himself to the shopkeeper he makes the purchase. Next, a blind person comes in to the shop wanting a pair of sunglasses. How did he indicate he wants them?");
     printf("  \n  a)By a written note\n  b)Signalling to his eyes\n  c)Asking for them\n  d)None of the above ");
     scanf("%s",&q5);
     if(q5=='c'|| q5=='C')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 6
     printf("\n6.Which is heavier a ton of gold or a ton of feathers?");
     printf("  \n  a)Silver\n  b)Feathers\n  c)Gold\n  d)None of the above ");
     scanf("%s",&q6);
     if(q6=='d'|| q6=='D')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 7
     printf("\n7.Is it legal for a man to marry his widow's sister?");
     printf("  \n  a)Yes\n  b)No\n  c)Depends on the country's law");
     scanf("%s",&q7);
     if(q7=='b'|| q7=='B')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 8
     printf("\n8.How many times can you subtract 10 from 100?");
     printf("  \n  a)11 times\n  b)10 times\n  c)Once\n  d)None of the above ");
     scanf("%s",&q8);
     if(q8=='c'|| q8=='C')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 9
     printf("\n9.Jan's mother had three children. The first Child was named April. The second child was named May. What was the third child's name?");
     printf("  \n  a)March\n  b)June\n  c)Jan\n  d)None of the above ");
     scanf("%s",&q9);
     if(q9=='c'|| q9=='C')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 10
     printf("\n10.Before Mt.Everest was discovered, which was the highest mountain in the world?");
     printf("  \n  a)Mt.Aconcagua\n  b)Mt.Mckinley\n  c)Mt.Everest\n  d)None of the above ");
     scanf("%s",&q10);
     if(q10=='c'|| q10=='C')
     {
          printf("\nCorrect Answer. Press a key to go to next question.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to go to next question.");
          w=w+1;
          getch();    
     }
     system("cls");
//Question 11
     printf("\n11.If an electric train is traveling south, which way is the smoke going?");
     printf("  \n  a)West\n  b)North\n  c)South\n  d)None of the above ");
     scanf("%s",&q11);
     if(q11=='d'|| q11=='D')
     {
          printf("\nCorrect Answer. Press a key to get your results.");
          c=c+1;
          getch();
     }
     else
     {
          printf("\nWrong Answer. Press a key to get your results.");
          w=w+1;
          getch();    
     }
     system("cls");
     temp=(c*100)/11;
     printf("\nYou have answered %0.0f question/s correctly.",c);
     printf("\nYou have secured %0.2f%% on this test",temp);
     if(c>=9)
     {printf("\n\nYou are AWESOME!!!!, you have secured A+");}
     if(c>=7 && c<9)
     {printf("\n\nOk! You are not half bad as I thought.You have secured a B+. But you might want to consider retaking this quiz.");}
     if(c<7)
     {printf("\n\nYou totally SUCK!!!! Go back to ELEMENTARY school and REDO your BASICS. ");}
     getch();
     getch();
}
