#include<stdio.h>
#define one 1
#define ten 10
#define hundred 100
#define thousand 1000
int main(void)
{
	printf("%d %d %d %d\n",one,ten,hundred,thousand);
	printf("%f %f %f %f",one,ten,hundred,thousand);
}
