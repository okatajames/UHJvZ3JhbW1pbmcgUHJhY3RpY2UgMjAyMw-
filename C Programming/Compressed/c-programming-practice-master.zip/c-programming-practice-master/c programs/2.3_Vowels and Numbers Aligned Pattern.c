#include<stdio.h>
int main(void)
{
	printf("a e i o u\n");
	printf("0 2 4 6 8\n");
	printf("1 3 5 7 9");
	
}
