#include<stdio.h>

#line 100 "rokyslash.c"
//this line becomes 100
int main()
{
	printf("line: %d\n",__LINE__);
	printf("filename: %s\n",__FILE__);
	
}
