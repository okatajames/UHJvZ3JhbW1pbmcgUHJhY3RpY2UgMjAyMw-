#include<stdio.h>
int main(void)
{
	int i;
	printf("Enter an integer:");
	scanf("%d",&i);
	printf("%d %c %f",i,i,i);
}
