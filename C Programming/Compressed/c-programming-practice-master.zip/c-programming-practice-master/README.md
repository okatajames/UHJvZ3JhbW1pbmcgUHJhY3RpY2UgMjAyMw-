# c-programming-practice

Solutions to some of the problems from the book titled "C Programming & Data Structures by Forouzan". Learned C from this book.
